create view v_payroll_summary
            (employee_id, full_name, email, total_payrolls, total_earnings, avg_payment, last_payment_date) as
SELECT e.employee_id,
       e.full_name,
       e.email,
       count(p.payroll_id) AS total_payrolls,
       sum(p.total_paid)   AS total_earnings,
       avg(p.total_paid)   AS avg_payment,
       max(p.payment_date) AS last_payment_date
FROM employees e
         LEFT JOIN payroll p ON e.employee_id = p.employee_id
GROUP BY e.employee_id, e.full_name, e.email;

alter table v_payroll_summary
    owner to postgres;

