create view v_active_employees
            (employee_id, full_name, email, position, department, base_salary, hire_date, latest_score,
             last_review_date) as
SELECT e.employee_id,
       e.full_name,
       e.email,
       e."position",
       e.department,
       e.base_salary,
       e.hire_date,
       COALESCE(p.score, 0::numeric) AS latest_score,
       p.review_date                 AS last_review_date
FROM employees e
         LEFT JOIN LATERAL ( SELECT performance.score,
                                    performance.review_date
                             FROM performance
                             WHERE performance.employee_id = e.employee_id
                             ORDER BY performance.review_date DESC
                             LIMIT 1) p ON true
WHERE e.is_active = true;

alter table v_active_employees
    owner to postgres;

