create procedure calculate_payroll(IN p_employee_id integer, IN p_period_start date, IN p_period_end date, IN p_bonus numeric, IN p_deductions numeric)
    language plpgsql
as
$$
DECLARE
    v_base_salary DECIMAL(12,2);
    v_total_paid  DECIMAL(12,2);
    v_is_active   BOOLEAN;
BEGIN
    -- Validate employee exists and is active
    SELECT base_salary, is_active INTO v_base_salary, v_is_active
    FROM employees WHERE employee_id = p_employee_id;

    IF v_base_salary IS NULL THEN
        RAISE EXCEPTION 'Employee % not found', p_employee_id;
    END IF;

    IF NOT v_is_active THEN
        RAISE EXCEPTION 'Employee % is inactive', p_employee_id;
    END IF;

    -- Validate dates
    IF p_period_end < p_period_start THEN
        RAISE EXCEPTION 'End date must be >= start date';
    END IF;

    -- Validate amounts
    IF p_bonus < 0 OR p_deductions < 0 THEN
        RAISE EXCEPTION 'Bonus and deductions cannot be negative';
    END IF;

    -- Calculate total
    v_total_paid := v_base_salary + p_bonus - p_deductions;

    IF v_total_paid < 0 THEN
        RAISE EXCEPTION 'Total paid cannot be negative (deductions exceed salary + bonus)';
    END IF;

    -- Insert payroll record
    INSERT INTO payroll (employee_id, pay_period_start, pay_period_end,
                         base_salary, bonus, deductions, total_paid, payment_date)
    VALUES (p_employee_id, p_period_start, p_period_end,
            v_base_salary, p_bonus, p_deductions, v_total_paid, CURRENT_DATE);
END;
$$;

alter procedure calculate_payroll(integer, date, date, numeric, numeric) owner to postgres;

